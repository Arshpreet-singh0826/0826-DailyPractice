# Tutoria

An online Learning platform build in MERN Stack

## Frontend 
<ul> 
 <li> React Js </li>
 <li> Tailwind CSS </li>
</ul>

## Backend 

<ul>
<li> Node Js  </ li>
<li> Express Js </ li>
<li> MongoDb </ li>
<li> Mongoose </ li>
</ul>



: Work in progress 

